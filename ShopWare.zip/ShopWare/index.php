<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Store</title>
    <!-- Bootstrap 5 CDN -->
    <link rel="stylesheet" href="source/css/bootstrap.min.css">
    <link rel="stylesheet" href="wel.css">
</head>
<body>
<img src="source/images/Promotion1.png" style="width: 100%">
<?php include "pages.html" ?>
<?php if(isset($_GET['success'])) {?>
    <div class="alert alert-success" role="alert">
        <?=htmlspecialchars($_GET['success']); ?>
    </div>
<?php } ?>

<?php if(isset($_GET['error'])) {?>
    <div class="alert alert-danger" role="alert">
        <?=htmlspecialchars($_GET['error']); ?>
    </div>
<?php } ?>  
<form action="" method="POST" enctype="multipart/form-data">
<?php
$conn = mysqli_connect('localhost','root','5HW:QqaEbfJf_aE@','shop_db');
if(!$conn){
    echo 'connection error: ' . mysqli_connect_error();
}

$sql = 'SELECT * FROM products';
$result = mysqli_query($conn,$sql);

while($row = mysqli_fetch_array($result)) {
?>
<div class="color">
    <?php echo '<img src="data:image;base64,'.base64_encode($row['Image']).'" alt="Image" style="width: 200px; height: 200px;border-radius: 8px;">'; ?>
    <?php echo $row['Product_Name'].' '.$row['Product_Description'] ?>
    <button name="select" class="button" id="<?php echo $row['Product_ID']; ?>" onclick="func()" value="<?php echo $row['Product_ID']; ?>"><span><?php echo $row['Product_Price'] ?> SAR</span> Add to Cart</button>
</div>
<?php
}

if(isset($_POST['select'])) {
    if(is_numeric($_POST['select'])) {
        if (isset($_SESSION['userEmail']) && isset($_SESSION['userId']) ) {
            $productId = mysqli_real_escape_string($conn, $_POST['select']);
            $userId = mysqli_real_escape_string($conn, $_SESSION['userId']);

            $sql2 = "SELECT * FROM cart WHERE customer_ID=$userId AND Product_ID=$productId";
            $result2 = mysqli_query($conn, $sql2);

            if (!$row2 = mysqli_fetch_array($result2)) {
                $query = "INSERT INTO cart (customer_ID, Product_ID, Quantity) VALUES ($userId, $productId, '1')";
                $new = mysqli_query($conn, $query);

                if ($new) {
                    echo '<div id="message" class="message-box success-message">Item added to cart!</div>';
                    echo '<script>
                            window.onload = function () { 
                                document.getElementById("message").style.display = "block";
                                setTimeout(function(){ document.getElementById("message").style.display = "none"; }, 3000);
                            }
                          </script>';
                } else {
                    echo '<div id="message" class="message-box error-message">An error occurred while adding the item</div>';
                    echo '<script>
                            window.onload = function () { 
                                document.getElementById("message").style.display = "block";
                                setTimeout(function(){ document.getElementById("message").style.display = "none"; }, 3000);
                            }
                          </script>';
                }
            } else {
                echo '<div id="message" class="message-box error-message">The item is already in the cart. To add more quantities, please go to cart</div>';
                echo '<script>
                            window.onload = function () { 
                                document.getElementById("message").style.display = "block";
                                setTimeout(function(){ document.getElementById("message").style.display = "none"; }, 3000);
                            }
                          </script>';
            }
        } else {
            echo '<script type="text/javascript">
                    window.location.replace("source/php/Login.php?error=Please Login Before Adding Items To the Cart");
                  </script>';
        }
    } else {
        echo '<script type="text/javascript">
                window.onload = function () { alert("Invalid input"); }
              </script>';
    }
}
?>    
</form>
</body>
</html>
