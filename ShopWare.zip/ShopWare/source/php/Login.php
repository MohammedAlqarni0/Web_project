<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        /* Additional styles for this page */
        body {
            font-family: Arial, Helvetica, sans-serif;
            margin: 0;
            background-color: #f8f9fa; /* Light gray background */
            color: #343a40; /* Dark gray text color */
        }

        .navbar {
            background-color: #ff7f50 !important; /* Orange navbar */
        }

        .navbar-brand,
        .nav-link {
            color: #fff !important; /* White text for navbar items */
        }

        .container {
            max-width: 40rem; /* Adjusted container width */
            margin-top: 50px; /* Added margin for spacing */
        }

        .form-container {
            background-color: #fff; /* White background for form */
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 80%; /* Increased width of the form container */
            max-width: 800px; /* Maximum width of the form container */
            margin: 0 auto; /* Center the form container */
        }

        .form-container h1 {
            color: #343a40; /* Dark gray title color */
            margin-bottom: 20px;
        }

        .form-container .form-control {
            margin-bottom: 20px;
            border-radius: 8px;
            font-size: 20px; /* Increased font size for form inputs */
        }

        .form-container .btn-primary {
            background-color: #ff7f50; /* Orange login button */
            border-color: #ff7f50;
            border-radius: 8px;
            width: 100%;
            padding: 15px; /* Increased padding for button */
            font-size: 20px; /* Increased font size for button */
        }

        /* Additional styles for Register button */
        .register-btn {
            background-color: #28a745; /* Green register button */
            border-color: #28a745;
            border-radius: 8px;
            width: 100%;
            padding: 15px; /* Increased padding for button */
            font-size: 20px; /* Increased font size for button */
            margin-top: 20px;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="../../index.php">Store</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../../index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="Login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="LoginAdmin.php">Login For Admin</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="d-flex justify-content-center align-items-center">
            <form class="shadow-lg p-3 mb-5 bg-white rounded form-container" method="POST" action="authenticate.php">
                <h1 class="mb-4">Login</h1>

                <?php if(isset($_GET['success'])) {?>
                    <div class="alert alert-success" role="alert">
                        <?=htmlspecialchars($_GET['success']); ?>
                    </div>
                <?php } ?>
                
                <?php if(isset($_GET['error'])) {?>
                    <div class="alert alert-danger" role="alert">
                        <?=htmlspecialchars($_GET['error']); ?>
                    </div>
                <?php } ?>

                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email">
                </div>

                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" name="pass">
                </div>

                <button type="submit" class="btn btn-primary">Login</button>
                  <br><br>
                <a href="signup.php" class="btn btn-primary">Register</a>
            </form>
        </div>
    </div>

</body>

</html>
