<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        /* Additional styles for this page */
        body {
            font-family: Arial, Helvetica, sans-serif;
            margin: 0;
            background-color: #f8f9fa; /* Light gray background */
            color: #343a40; /* Dark gray text color */
        }

        .navbar {
            background-color: #ff7f50 !important; /* Orange navbar */
        }

        .navbar-brand,
        .nav-link {
            color: #fff !important; /* White text for navbar items */
        }

        .about-section {
            padding: 50px;
            text-align: center;
            background-color: #ff7f50; /* Orange background */
            color: #fff; /* White text color */
        }

        .title {
            color: #343a40; /* Dark gray title color */
            font-weight: bold;
        }

        .column {
            float: left;
            width: 25%;
            margin-bottom: 16px;
            padding: 0 8px;
        }

        .card {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            margin: 8px;
            background-color: #ffffff; /* White card background */
            color: #343a40; /* Dark gray text color */
            border-radius: 10px;
            padding: 20px;
            transition: transform 0.3s ease-in-out;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .button {
            background-color: #343a40; /* Dark gray button background */
            color: #fff; /* White button text color */
            border: none;
            outline: none;
            padding: 8px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #495057; /* Darker gray on hover */
        }

        @media screen and (max-width: 768px) {
            .column {
                width: 50%;
            }
        }

        @media screen and (max-width: 480px) {
            .column {
                width: 100%;
            }
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="../../index.php">Store</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../../index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="Login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="LoginAdmin.php">Login For Admin</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="about-section">
        <h1>About Us</h1>
        <p>We are a team of Saudi students from IAU who specialize in web development.</p>
    </div>

    <h2 style="text-align:center">Our Team</h2>
    <div class="row">
        <div class="column">
            <div class="card">
                <div class="container">
                    <h2>Mohammed  Alqarni</h2>
                    <p class="title">CEO & Founder</p>
                    <p><a href="mailto:2210001901@iau.edu.sa">2210001901@iau.edu.sa</a></p>
                </div>
            </div>
        </div>

        <div class="column">
            <div class="card">
                <div class="container">
                    <h2>Waleed  Alamoudi</h2>
                    <p class="title">Cybersecurity Analyst</p>
                    <p><a href="mailto:2210002340@iau.edu.sa">2210002340@iau.edu.sa</a></p>
                </div>
            </div>
        </div>

        <div class="column">
            <div class="card">
                <div class="container">
                    <h2>Abdulkareem  Alhabib</h2>
                    <p class="title">Cybersecurity Analyst</p>
                    <p><a href="mailto:2210002212@iau.edu.sa">2210002212@iau.edu.sa</a></p>
                </div>
            </div>
        </div>
        
        <div class="column">
            <div class="card">
                <div class="container">
                    <h2>Omar Alkhowaiter</h2>
                    <p class="title">Cybersecurity Analyst</p>
                    <p><a href="mailto:2210002396@iau.edu.sa">2210002396@iau.edu.sa</a></p>
                </div>
            </div>
        </div>

        <div class="column">
            <div class="card">
            <div class="container">
                    <h2>Yousef Alqahtani</h2>
                    <p class="title">Cybersecurity Analyst</p>
                    <p><a href="mailto:2210002162@iau.edu.sa">2210002162@iau.edu.sa</a></p>
                </div>
            </div>
        </div>
               
