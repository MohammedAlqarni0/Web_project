<?php
try
{
session_start();
if(isset($_POST['email']) && isset($_POST['pass']) &&!empty($_POST['pass'] && !empty($_POST['email'])))
{
  require "db_conn.php";
  include "vald.php";
  /**Get data from the request*/
  $email = $_POST['email'];
  $pass = $_POST['pass'];

  $text = "Email";
  $loc = "LoginAdmin.php";
  $ms = "error";
  is_empty($email,$text,$loc,$ms, "");

  $text = "Password";
 
  is_empty($pass,$text,$loc,$ms, "");

  #search for the email 
  $sql = "SELECT * FROM admin
          WHERE email=?";

  $stmt = $connection->prepare($sql);
  $stmt->execute([$email]);

  $user = $stmt->fetch();

  $userId = $user['ID'];
  $userEmail = $user['email'];
  $userPass = $user['password'];
  
  $sha384Hash = hash('sha384', $pass);
  

  
  // Check the Password and the Email

  if ($email === $userEmail && $sha384Hash === $userPass && !is_null($userEmail) && !is_null($userPass) ) {
    $_SESSION['adminId'] = $userId;
    $_SESSION['adminEmail'] = $userEmail;
    header("Location: admin.php");
    }else { // if the password or Email incorrect
    	        $msg = "The email or password provided is incorrect. Please check and try again.";
    	        header("Location: LoginAdmin.php?error=$msg");
    		  }

}else {
	$msg = "All fields must be filled out.";
	header("Location: LoginAdmin.php?error=$msg");
}
}

catch(Exception $e)
{
  $msg = "The username or password you entered is incorrect. Please check and try again.";
  header("Location: LoginAdmin.php?error=$msg");
}


?>
