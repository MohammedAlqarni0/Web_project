<?php
    session_start();
   
    if (isset($_SESSION['adminEmail']) &&
        isset($_SESSION['adminId']) ) {
        
        if (isset($_GET['id'])) { # if product selected 
            include "db_conn.php";
            $id = $_GET['id'];  
            $sql = "DELETE FROM invoice WHERE Invoice_ID=?";
            $stmt = $connection->prepare($sql);
            $stmt->bindValue(1,$id);
            $res  = $stmt->execute();
            
            if ($res) {
                # success message
                $successMsg = "The order has been successfully deleted.";
                header("Location: Invoice.php?success=$successMsg");
            }else {
                $fillMsg = "An error occurred.";
                header("Location: Invoice.php?error=$fillMsg");
               exit;
            }               
        }
        else { # if order not selected 
            header("Location: admin.php?error=not selected order");
        }
             
     
    } else { # if the admin not login 
        $msg = "To delete orders, please log in as an admin.";
        header("Location: LoginAdmin.php?error=$msg");
        exit; } 
?>