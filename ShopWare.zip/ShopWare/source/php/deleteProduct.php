<?php
    session_start();
   
    if (isset($_SESSION['adminEmail']) &&
        isset($_SESSION['adminId']) ) {
        
        if (isset($_GET['id'])) { # if product selected 
            include "db_conn.php";
            $id = $_GET['id'];  
            $sql = "DELETE FROM products WHERE Product_ID=?";
            $stmt = $connection->prepare($sql);
            $stmt->bindValue(1,$id);
            $res  = $stmt->execute();
            
            if ($res) {
                # success message
                $successMsg = "The product has been successfully deleted.";
                header("Location: admin.php?success=$successMsg");
            }else {
                $fillMsg = "An error occurred.";
                header("Location: admin.php?error=$fillMsg");
               exit;
            }               
        }
        else { # if product not selected 
            header("Location: admin.php?error=not selected product");
        }
             
     
    } else { # if the admin not login 
        $msg = "To delete products, please log in as an admin.";
        header("Location: LoginAdmin.php?error=$msg");
        exit; } 
?>